# Navimex OTO RADYO DSP APK projesi

Bu proje, `radio.html` dosyasını Android WebView içinde tam ekran ve dikey kullanım için çalıştırır.

## APK oluşturma
1. Android Studio ile bu klasörü açın.
2. Gradle senkronizasyonunun tamamlanmasını bekleyin.
3. **Build > Build APK(s)** seçin.
4. Oluşan debug APK'yı Navimex'e kurun.

Uygulama internet izni ister; radyo yayınları, HLS.js ve hava durumu için gereklidir. Projede hazır APK değil, APK üretmeye hazır kaynak proje bulunur; bu çalışma ortamında Android SDK/Java/Gradle olmadığı için burada derlenmiş APK üretilemedi.
